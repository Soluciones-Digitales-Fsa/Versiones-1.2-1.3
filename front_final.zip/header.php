<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>DevNode | Portfolio</title>
  <link rel="stylesheet" href="estilos.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body>
<header>
  <<div class="container">
      <img src="" alt=""/>

    <!-- Enlace de login -->
    <a href="login.php" class="login-link">Login</a>

    <nav>
      <ul class="nav-links">
        <li><a href="#inicio">Inicio</a></li>
        <li><a href="#nosotros">Nosotros</a></li>
        <li><a href="#equipo">Equipo</a></li>
        <li><a href="#idiomas">Idiomas</a></li>
        <li><a href="#proyectos">Proyectos</a></li>
        <li><a href="#herramientas">Herramientas</a></li>
        <li><a href="#testimonios">Testimonios</a></li>
        <li><a href="#contacto">Contacto</a></li>
      </ul>
    </nav>
  </div>
</header>

      </nav>
    </div>
  </header>


