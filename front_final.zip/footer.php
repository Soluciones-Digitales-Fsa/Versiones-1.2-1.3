<footer>
  <div class="container">
    <div class="social-links">
      <a href="https://www.instagram.com/devnode25" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a>
      <a href="https://www.linkedin.com/in/dev-node-271405363" target="_blank" title="LinkedIn"><i class="fab fa-linkedin"></i></a>
      <a href="https://github.com/JuValeria" target="_blank" title="GitHub"><i class="fab fa-github"></i></a>
    </div>
    <p>&copy; <?php echo date("Y"); ?> DevNode. Todos los derechos reservados.</p>
  </div>
</footer>

<!-- Botón flotante de WhatsApp -->
<a href="https://wa.me/549XXXXXXXXXX" class="whatsapp-float" target="_blank" title="WhatsApp">
  <i class="fab fa-whatsapp"></i>
</a>

<!-- Botón volver arriba -->
<a href="#inicio" class="scroll-top" title="Volver arriba">
  <i class="fas fa-chevron-up"></i>
</a>

</body>
</html>

